function [res] = ustep(N)
    res = ones(1, N)
end